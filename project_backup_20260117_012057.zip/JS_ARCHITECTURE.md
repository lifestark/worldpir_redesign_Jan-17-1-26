# JavaScript Архитектура

## 📂 Структура

```
src/js/
├── main.js                      # Точка входа, инициализация всех компонентов
└── components/                  # Модули компонентов
    ├── navigation.js            # Навигация и бургер-меню
    ├── gallery.js               # Слайдер галереи
    ├── modal.js                 # Модальные окна
    ├── FAQ_accordeon.js         # FAQ аккордеон
    ├── phone_mask.js            # Маска телефона + плавный скролл
    └── scroll_animation.js      # Анимация при скролле
```

## 🔧 Компоненты

### 1. **Navigation** (`navigation.js`)
**Класс:** `Navigation`

**Функции:**
- Управление навигационным меню
- Бургер-меню для мобильных устройств
- Изменение стиля при скролле
- Автоматическое определение наличия hero-секции

**Использование:**
```javascript
new Navigation();
```

### 2. **GallerySlider** (`gallery.js`)
**Класс:** `GallerySlider`

**Функции:**
- Слайдер без библиотек
- Поддержка touch-событий (свайпы)
- Навигация стрелками и точками
- Опциональный автоплей

**Использование:**
```javascript
new GallerySlider('gallerySlider');
```

### 3. **Modal** (`modal.js`)
**Класс:** `Modal`

**Функции:**
- Открытие/закрытие модальных окон
- Обработка форм
- Закрытие по Escape
- Автофокус на первом поле

**Использование:**
```javascript
new Modal();
```

**HTML атрибуты:**
```html
<button data-modal="order" data-package="basic">Заказать</button>
```

### 4. **FAQ** (`FAQ_accordeon.js`)
**Класс:** `FAQ`

**Функции:**
- Аккордеон для FAQ секции
- Опция закрытия других элементов при открытии

**Использование:**
```javascript
new FAQ();
```

### 5. **PhoneMask** (`phone_mask.js`)
**Класс:** `PhoneMask`

**Функции:**
- Маска для телефонного номера
- Формат: +7 (XXX) XXX-XX-XX
- Автоматическое форматирование

**Использование:**
```javascript
const phoneInput = document.getElementById('phone');
new PhoneMask(phoneInput);
```

### 6. **SmoothScroll** (`phone_mask.js`)
**Класс:** `SmoothScroll`

**Функции:**
- Плавная прокрутка к якорям
- Учитывает высоту фиксированной навигации

**Использование:**
```javascript
new SmoothScroll();
```

### 7. **initScrollAnimations** (`scroll_animation.js`)
**Функция:** `initScrollAnimations()`

**Функции:**
- Анимация появления элементов при скролле
- Использует IntersectionObserver API
- Каскадная задержка анимации

**Использование:**
```javascript
initScrollAnimations();
```

## 🚀 Инициализация

Все компоненты инициализируются в `main.js` при загрузке DOM:

```javascript
document.addEventListener('DOMContentLoaded', () => {
    new Navigation();
    new GallerySlider('gallerySlider');
    new FAQ();
    new Modal();
    
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        new PhoneMask(phoneInput);
    }
    
    new SmoothScroll();
    initScrollAnimations();
});
```

## 📝 Порядок подключения в HTML

**ВАЖНО:** Скрипты должны быть подключены в правильном порядке!

```html
<!-- Компоненты -->
<script src="src/js/components/navigation.js"></script>
<script src="src/js/components/gallery.js"></script>
<script src="src/js/components/modal.js"></script>
<script src="src/js/components/FAQ_accordeon.js"></script>
<script src="src/js/components/phone_mask.js"></script>
<script src="src/js/components/scroll_animation.js"></script>

<!-- Инициализация -->
<script src="src/js/main.js"></script>
```

## ➕ Добавление нового компонента

### Шаг 1: Создайте файл
Создайте файл в `src/js/components/my-component.js`

### Шаг 2: Напишите класс
```javascript
/**
 * ================================================
 * MY COMPONENT
 * Описание компонента
 * ================================================
 */
class MyComponent {
    constructor(options) {
        this.options = options;
        this.init();
    }
    
    init() {
        // Инициализация
    }
    
    // Методы...
}
```

### Шаг 3: Подключите в HTML
```html
<script src="src/js/components/my-component.js"></script>
```

### Шаг 4: Инициализируйте в main.js
```javascript
document.addEventListener('DOMContentLoaded', () => {
    // ...другие компоненты
    new MyComponent({ option: 'value' });
});
```

## 🔍 Отладка

### Проверка инициализации
Откройте консоль браузера (F12) и проверьте:
```javascript
// Проверить, что классы доступны
console.log(typeof Navigation);  // должно быть "function"
console.log(typeof Modal);       // должно быть "function"
```

### Частые проблемы

**Проблема:** `Uncaught ReferenceError: Navigation is not defined`
**Решение:** Проверьте порядок подключения скриптов. Компоненты должны быть подключены ДО main.js

**Проблема:** Слайдер не работает
**Решение:** Убедитесь, что элемент с ID существует в HTML:
```javascript
const slider = document.getElementById('gallerySlider');
console.log(slider); // не должно быть null
```

**Проблема:** Модалка не открывается
**Решение:** Проверьте наличие атрибута `data-modal`:
```html
<button data-modal="order">Открыть</button>
```

## 🎯 Best Practices

✅ **Один компонент = один файл**
✅ **Используйте классы ES6**
✅ **Документируйте сложные методы**
✅ **Проверяйте существование элементов перед работой с ними**
✅ **Не забывайте про accessibility (aria-атрибуты)**
✅ **Используйте event delegation для динамических элементов**

## 🔒 Безопасность

- Валидируйте данные форм на клиенте И сервере
- Используйте `textContent` вместо `innerHTML` где возможно
- Санитизируйте пользовательский ввод

## 📱 Совместимость

Код написан на ES6+ и требует современных браузеров:
- Chrome 51+
- Firefox 54+
- Safari 10+
- Edge 15+

Для поддержки старых браузеров используйте Babel.

## ⚡ Оптимизация для продакшена

### Минификация
```bash
# Установите Terser
npm install -g terser

# Минифицируйте каждый файл
terser src/js/main.js -o dist/main.min.js
terser src/js/components/navigation.js -o dist/components/navigation.min.js
# и т.д.
```

### Объединение файлов
```bash
# Объедините все в один файл
cat src/js/components/*.js src/js/main.js > dist/bundle.js

# Минифицируйте
terser dist/bundle.js -o dist/bundle.min.js
```

Тогда в HTML:
```html
<script src="dist/bundle.min.js"></script>
```

## 📚 Дополнительная информация

- **ES6 Classes:** https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Classes
- **IntersectionObserver:** https://developer.mozilla.org/ru/docs/Web/API/Intersection_Observer_API
- **Touch Events:** https://developer.mozilla.org/ru/docs/Web/API/Touch_events

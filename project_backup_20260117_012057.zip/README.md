# Вселенная праздников — Шаблон сайта

Современный, масштабируемый шаблон сайта агентства по организации детских и семейных праздников.

## 🎯 Описание

Полностью готовый к использованию шаблон сайта с чистым кодом, современным дизайном и адаптивной версткой. Написан на чистом HTML5, CSS3 и JavaScript (ES6+) без использования фреймворков и библиотек.

## 📁 Структура проекта

```
/
├── index.html              # Главная страница
├── src/
│   ├── css/
│   │   ├── main.css        # Главный файл (импорты всех модулей)
│   │   ├── base/           # Базовые стили
│   │   │   ├── variables.css    # CSS переменные
│   │   │   ├── reset.css        # Сброс стилей
│   │   │   ├── typography.css   # Типографика
│   │   │   └── utilities.css    # Вспомогательные классы
│   │   ├── layout/         # Структура страницы
│   │   │   ├── container.css    # Контейнер
│   │   │   └── section.css      # Базовые секции
│   │   ├── components/     # Переиспользуемые компоненты
│   │   │   ├── buttons.css      # Кнопки
│   │   │   ├── cards.css        # Карточки
│   │   │   ├── modal.css        # Модальные окна
│   │   │   ├── form.css         # Формы
│   │   │   └── navigation.css   # Навигация
│   │   └── sections/       # Секции страницы
│   │       ├── hero.css         # Hero секция
│   │       ├── services.css     # Услуги
│   │       ├── packages.css     # Пакеты
│   │       ├── benefits.css     # Преимущества
│   │       ├── gallery.css      # Галерея
│   │       ├── reviews.css      # Отзывы
│   │       ├── faq.css          # FAQ
│   │       ├── cta.css          # CTA
│   │       └── footer.css       # Футер
│   ├── js/
│   │   ├── navigation.js   # Логика навигации
│   │   └── main.js         # Основной JavaScript
│   └── img/                # Папка для изображений
└── README.md               # Документация
```

## 🎨 Особенности дизайна

- **Цветовая схема:**
  - Основной: светло-фиолетовый (`#b794f6`)
  - Акцентный: `#6c63ff`
  - Белый, черный и оттенки серого

- **Стиль:** Современный, воздушный, профессиональный
- **Типографика:** Системные шрифты для быстрой загрузки

## 🛠 Технологии

- **HTML5** — семантическая разметка
- **CSS3** — CSS Variables, Flexbox, Grid
- **JavaScript (ES6+)** — классы, модули, современный синтаксис
- **BEM** — методология именования классов
- **Mobile-first** — адаптивный подход

## 📱 Адаптивность

Полная поддержка всех устройств:
- Desktop (1200px+)
- Tablet (768px - 1024px)
- Mobile (320px - 767px)

## 🧩 Компоненты

### Навигация
- 3 зоны: логотип / меню / контакты
- Два режима: с hero (прозрачная) и без (белая)
- Фиксированная на десктопе
- Бургер-меню на мобильных
- Плавные переходы при скролле

### Секции
1. **Hero** — Главный экран с призывом к действию
2. **Услуги** — Карточки услуг (6 штук)
3. **Пакеты** — 3 тарифных плана
4. **Преимущества** — 4 преимущества компании
5. **Галерея** — Слайдер без библиотек
6. **Отзывы** — 3 отзыва клиентов
7. **FAQ** — Аккордеон с вопросами
8. **CTA** — Призыв к действию
9. **Footer** — Подвал с информацией

### UI Компоненты
- **Кнопки:** primary, secondary, outline (3 размера)
- **Карточки:** услуги, пакеты
- **Модальное окно** с формой заказа
- **Форма:** валидация, маска телефона
- **Слайдер:** touch-события, точки навигации

## 🚀 Как использовать

### Быстрый старт

1. Скачайте все файлы
2. Откройте `index.html` в браузере
3. Готово!

### Локальный сервер (рекомендуется)

```bash
# Используйте любой простой HTTP-сервер
# Python 3
python -m http.server 8000

# Node.js (http-server)
npx http-server

# VS Code (Live Server extension)
# Клик правой кнопкой на index.html > Open with Live Server
```

Затем откройте `http://localhost:8000` в браузере.

## 📝 Настройка контента

### Изменение цветов

Откройте `src/css/base/variables.css` и измените CSS-переменные:

```css
:root {
    --color-primary: #b794f6;      /* Основной цвет */
    --color-accent: #6c63ff;       /* Акцентный цвет */
    /* ... другие переменные */
}
```

### Изменение текста

Все тексты находятся в `index.html`. Найдите нужную секцию и замените заглушки на реальный контент.

### Добавление изображений

1. Поместите изображения в папку `src/img/`
2. В HTML замените заглушки:

```html
<!-- Было -->
<div class="gallery__placeholder">Праздник 1</div>

<!-- Стало -->
<img src="src/img/party-1.jpg" alt="Детский праздник">
```

### Изменение контактов

Найдите в `index.html`:

```html
<a href="tel:+70000000000">+7 (000) 000-00-00</a>
<a href="mailto:info@universe-party.ru">info@universe-party.ru</a>
```

Замените на реальные данные.

## 🔧 Расширение функционала

### Добавление новой секции

1. Создайте HTML-разметку в `index.html`:

```html
<section class="section" id="new-section">
    <div class="container">
        <h2 class="section__title">Новая секция</h2>
        <!-- Ваш контент -->
    </div>
</section>
```

2. Создайте файл стилей `src/css/sections/new-section.css`
3. Импортируйте его в `src/css/main.css`:
```css
@import url('sections/new-section.css');
```
4. При необходимости добавьте JavaScript в `src/js/main.js`

### Интеграция с backend

В `src/js/main.js` найдите метод `handleSubmit` класса `Modal`:

```javascript
handleSubmit(e) {
    e.preventDefault();
    
    const formData = new FormData(this.form);
    
    // Отправка на сервер
    fetch('/api/orders', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert('Заявка отправлена!');
        this.close();
    })
    .catch(error => {
        alert('Ошибка отправки');
    });
}
```

### Добавление аналитики

В `<head>` секцию `index.html` добавьте:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>

<!-- Yandex.Metrika -->
<script type="text/javascript">
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();
   for (var j = 0; j < document.scripts.length; j++) {if (document.scripts[j].src === r) { return; }}
   k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

   ym(COUNTER_ID, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true
   });
</script>
```

## 🎯 SEO оптимизация

### Meta теги

Отредактируйте в `<head>`:

```html
<meta name="description" content="Ваше описание">
<meta name="keywords" content="ключевые, слова">
<meta property="og:title" content="Заголовок для соцсетей">
<meta property="og:description" content="Описание для соцсетей">
<meta property="og:image" content="путь/к/изображению.jpg">
```

### Sitemap

Создайте `sitemap.xml` в корне:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://ваш-сайт.ru/</loc>
    <priority>1.0</priority>
  </url>
</urlset>
```

## 🐛 Отладка

### Проверка кода

```bash
# HTML валидация
https://validator.w3.org/

# CSS валидация
https://jigsaw.w3.org/css-validator/
```

### Тестирование на устройствах

- Chrome DevTools (F12) → Device Toolbar
- Firefox Developer Tools → Responsive Design Mode
- Реальные устройства для финального тестирования

## 📊 Производительность

### Оптимизация изображений

```bash
# Используйте современные форматы
WebP для фото
SVG для иконок

# Сжатие
https://tinypng.com/
https://squoosh.app/
```

### Минификация

Для продакшена рекомендуется минифицировать CSS и JS:

```bash
# CSS
npx cssnano src/css/base.css src/css/base.min.css

# JavaScript
npx terser src/js/main.js -o src/js/main.min.js
```

## 🔒 Безопасность

- Все формы валидируются на клиенте
- Добавьте серверную валидацию
- Используйте HTTPS в продакшене
- Добавьте reCAPTCHA для форм

## 📄 Лицензия

Свободная для коммерческого и личного использования.

## 🤝 Поддержка

При возникновении вопросов:
1. Проверьте консоль браузера (F12)
2. Убедитесь, что все файлы загружены
3. Проверьте пути к файлам

## 🎓 Дальнейшее развитие

### Рекомендуемые улучшения:
- Добавить реальные изображения
- Интегрировать с CMS (WordPress, Strapi)
- Добавить блог
- Подключить онлайн-оплату
- Добавить личный кабинет
- Многоязычность
- Темная тема

### Возможные интеграции:
- Google Maps для карты офисов
- Instagram API для галереи
- WhatsApp для мгновенных сообщений
- CRM системы для управления заказами

---

**Успехов в развитии проекта! 🎉**

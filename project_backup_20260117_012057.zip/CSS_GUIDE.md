# 🚀 Быстрый старт — CSS структура

## Структура проекта

```
src/css/
├── main.css              ← Главный файл (подключаем в HTML)
│
├── base/                 ← Базовые стили
│   ├── variables.css     ← Все CSS переменные
│   ├── reset.css         ← Сброс браузерных стилей
│   ├── typography.css    ← H1-H6, параграфы
│   └── utilities.css     ← .hidden, .text-center
│
├── layout/               ← Структура страницы
│   ├── container.css     ← .container
│   └── section.css       ← .section, .section__title
│
├── components/           ← Компоненты UI
│   ├── buttons.css       ← .btn, .btn--primary
│   ├── cards.css         ← .card, .card--service
│   ├── modal.css         ← .modal
│   ├── form.css          ← .form, .form__input
│   └── navigation.css    ← .navigation
│
└── sections/             ← Секции сайта
    ├── hero.css          ← Hero секция
    ├── services.css      ← Услуги
    ├── packages.css      ← Пакеты
    ├── benefits.css      ← Преимущества
    ├── gallery.css       ← Галерея
    ├── reviews.css       ← Отзывы
    ├── faq.css           ← FAQ
    ├── cta.css           ← CTA блок
    └── footer.css        ← Футер
```

## 🎨 Где что менять?

| Что нужно изменить | Файл |
|-------------------|------|
| Цвета проекта | `base/variables.css` |
| Шрифты и размеры | `base/variables.css` |
| Отступы | `base/variables.css` |
| Кнопки | `components/buttons.css` |
| Карточки услуг/пакетов | `components/cards.css` |
| Модальные окна | `components/modal.css` |
| Формы | `components/form.css` |
| Навигацию | `components/navigation.css` |
| Hero секцию | `sections/hero.css` |
| Футер | `sections/footer.css` |
| Любую другую секцию | `sections/{название}.css` |

## ➕ Добавить новый компонент

1. Создайте файл: `src/css/components/my-component.css`
2. Напишите стили
3. Добавьте импорт в `main.css`:
   ```css
   @import url('components/my-component.css');
   ```

## ➕ Добавить новую секцию

1. Создайте файл: `src/css/sections/my-section.css`
2. Напишите стили
3. Добавьте импорт в `main.css`:
   ```css
   @import url('sections/my-section.css');
   ```

## 🎯 Частые задачи

### Изменить основной цвет
Откройте `base/variables.css`:
```css
--color-primary: #новый-цвет;
```

### Изменить размер контейнера
Откройте `base/variables.css`:
```css
--container-max-width: 1400px;
```

### Добавить новую кнопку
Откройте `components/buttons.css`:
```css
.btn--danger {
    background-color: var(--color-error);
    color: var(--color-white);
}
```

### Изменить высоту Hero
Откройте `sections/hero.css`:
```css
.hero {
    min-height: 80vh; /* было 100vh */
}
```

## 📱 Адаптивность

Медиа-запросы находятся в тех же файлах, в конце:

```css
/* Основные стили */
.card {
    padding: var(--spacing-lg);
}

/* Адаптив для планшетов */
@media (max-width: 768px) {
    .card {
        padding: var(--spacing-md);
    }
}

/* Адаптив для мобильных */
@media (max-width: 480px) {
    .card {
        padding: var(--spacing-sm);
    }
}
```

## 🔍 Поиск стилей

Используйте поиск по файлам:

- Ищете стили навигации? → `components/navigation.css`
- Ищете стили кнопок? → `components/buttons.css`
- Ищете стили Hero? → `sections/hero.css`
- Ищете CSS переменные? → `base/variables.css`

## ⚡ Оптимизация для продакшена

Для production объедините все CSS в один файл и минифицируйте:

```bash
# Онлайн инструменты:
https://cssminifier.com/
https://cssnano.co/playground/

# Или через PostCSS:
npm install -g postcss-cli postcss-import cssnano
postcss src/css/main.css -o dist/style.min.css
```

## 💡 Советы

✅ Используйте CSS переменные из `variables.css`
✅ Следуйте BEM: `.block__element--modifier`
✅ Пишите комментарии для сложной логики
✅ Тестируйте на разных разрешениях
✅ Не дублируйте код — выносите в переменные

## 📚 Документация

- Полная документация: `CSS_ARCHITECTURE.md`
- Общая информация: `README.md`

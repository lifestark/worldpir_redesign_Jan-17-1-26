# Архитектура CSS

## Модульная структура

CSS разделён на логические блоки по папкам для лучшей организации и поддержки кода.

## 📂 Структура папок

### `base/` — Базовые стили
Фундаментальные стили, которые используются по всему проекту:
- **variables.css** — CSS переменные (цвета, шрифты, отступы, тени и т.д.)
- **reset.css** — Сброс стилей браузера
- **typography.css** — Типографика (заголовки, параграфы)
- **utilities.css** — Вспомогательные классы (.hidden, .text-center и т.д.)

### `layout/` — Структура страницы
Базовая структура и контейнеры:
- **container.css** — Контейнер для контента
- **section.css** — Базовые стили для секций

### `components/` — Переиспользуемые компоненты
Независимые компоненты интерфейса:
- **buttons.css** — Кнопки (primary, secondary, outline)
- **cards.css** — Карточки (услуги, пакеты)
- **modal.css** — Модальные окна
- **form.css** — Формы и элементы ввода
- **navigation.css** — Навигационное меню

### `sections/` — Секции страницы
Стили для конкретных секций сайта:
- **hero.css** — Главная секция
- **services.css** — Секция услуг
- **packages.css** — Секция пакетов
- **benefits.css** — Секция преимуществ
- **gallery.css** — Галерея/слайдер
- **reviews.css** — Отзывы
- **faq.css** — FAQ
- **cta.css** — Призыв к действию
- **footer.css** — Футер

## 🔧 Принципы организации

### 1. Один файл — одна ответственность
Каждый файл отвечает за конкретный компонент или секцию.

### 2. BEM методология
Используется для именования классов:
```css
.block {}
.block__element {}
.block--modifier {}
```

### 3. CSS Variables
Все переменные в `base/variables.css` для централизованного управления.

### 4. Mobile-first
Базовые стили для мобильных, медиа-запросы для больших экранов.

### 5. Модульность
Компоненты независимы и могут использоваться повторно.

## 📥 Подключение

Все модули импортируются в `main.css`:

```css
/* Base */
@import url('base/variables.css');
@import url('base/reset.css');
@import url('base/typography.css');
@import url('base/utilities.css');

/* Layout */
@import url('layout/container.css');
@import url('layout/section.css');

/* Components */
@import url('components/buttons.css');
@import url('components/cards.css');
@import url('components/modal.css');
@import url('components/form.css');
@import url('components/navigation.css');

/* Sections */
@import url('sections/hero.css');
@import url('sections/services.css');
/* ... остальные секции */
```

В HTML подключается только один файл:
```html
<link rel="stylesheet" href="src/css/main.css">
```

## ➕ Добавление новых модулей

### Новый компонент
1. Создайте файл в `components/`
2. Напишите стили
3. Импортируйте в `main.css`

Пример `components/tooltip.css`:
```css
/* ================================================
   TOOLTIP
   Всплывающая подсказка
   ================================================ */

.tooltip {
    position: relative;
    /* стили... */
}
```

Добавьте в `main.css`:
```css
@import url('components/tooltip.css');
```

### Новая секция
1. Создайте файл в `sections/`
2. Напишите стили для секции
3. Импортируйте в `main.css`

## 🎯 Преимущества модульной структуры

✅ **Понятность** — легко найти нужный код
✅ **Масштабируемость** — просто добавлять новые модули
✅ **Поддержка** — изменения в одном модуле не влияют на другие
✅ **Переиспользование** — компоненты можно использовать в других проектах
✅ **Производительность** — для продакшена можно минифицировать в один файл
✅ **Командная работа** — разные разработчики могут работать над разными модулями

## 🔨 Сборка для продакшена

Для продакшена можно объединить все CSS в один файл:

```bash
# Установите postcss
npm install -g postcss-cli postcss-import cssnano

# Создайте postcss.config.js
echo "module.exports = {
  plugins: [
    require('postcss-import'),
    require('cssnano')
  ]
}" > postcss.config.js

# Соберите
postcss src/css/main.css -o dist/style.min.css
```

Или вручную скопируйте содержимое всех файлов в один и минифицируйте онлайн:
- https://cssminifier.com/
- https://cssnano.co/playground/

## 📚 Дополнительная информация

- Используйте комментарии для документирования сложной логики
- Следуйте единому стилю кодирования
- Не дублируйте код — выносите в переменные или общие классы
- Тестируйте изменения на всех разрешениях экрана

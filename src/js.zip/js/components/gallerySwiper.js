export default class GallerySwiper {
    constructor() {
        this.init();
    }

    async init() {
        // Ensure Swiper CSS is present
        const cssHref = 'https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.min.css';
        if (!document.querySelector(`link[href="${cssHref}"]`)) {
            const l = document.createElement('link');
            l.rel = 'stylesheet';
            l.href = cssHref;
            document.head.appendChild(l);
        }

        try {
            const mod = await import('https://cdn.jsdelivr.net/npm/swiper@12/swiper-bundle.esm.browser.min.js');
            const Swiper = mod.default;

            // Init swiper after module has loaded
            /* eslint-disable no-unused-vars */
            const swiper = new Swiper('.gallery-swiper', {
                slidesPerView: 1,
                spaceBetween: 30,
                loop: true,
                speed: 1000,
                effect: 'slide',
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
            });
            /* eslint-enable no-unused-vars */
        } catch (e) {
            // Fallback: fail silently but log for debugging
            // console.warn('Swiper failed to load:', e);
        }
    }
}

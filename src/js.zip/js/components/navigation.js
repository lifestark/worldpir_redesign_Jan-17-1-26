/**
 * ================================================
 * NAVIGATION.JS
 * Скрипт для навигационного меню
 * ================================================
 */

import { settings } from '../settings.js';

class Navigation {
    constructor() {
        // Элементы DOM
        this.nav = document.getElementById('mainNav');
        this.burgerBtn = document.getElementById('burgerBtn');
        this.mobileMenu = document.getElementById('mobileMenu');
        this.mobileClose = document.querySelector('.navigation__mobile-close');
        this.navLinks = document.querySelectorAll('.navigation__link, .navigation__mobile-link');

        // Состояние
        this.isMobileMenuOpen = false;
        this.lastScrollTop = 0;

        // Проверяем наличие hero секции
        this.hasHero = document.getElementById('hero') !== null;

        // Инициализация
        this.init();
    }

    /**
     * Recreate hero observer when warning bar height changes
     */
    _onWarningHeightChange() {
        if (this._heroObserver) {
            try { this._heroObserver.disconnect(); } catch (e) { /* ignore */ }
            this._heroObserver = null;
        }
        // small delay to allow CSS var to settle
        setTimeout(() => {
            if (this.hasHero) this.observeHero();
        }, 60);
    }

    init() {
        // Если нет hero, делаем навигацию сразу белой
        if (!this.hasHero && this.nav) {
            this.nav.classList.remove('navigation--with-hero');
            this.nav.classList.add('navigation--white');

            // важное: в белом состоянии показываем ТОЛЬКО тёмный логотип
            this._setLogoState(true);
        }

        // События
        if (this.burgerBtn) this.burgerBtn.addEventListener('click', () => this.toggleMobileMenu());
        if (this.mobileClose) this.mobileClose.addEventListener('click', () => this.closeMobileMenu());
        // Always listen to scroll to keep state in sync; handler will ignore mobile widths
        window.addEventListener('scroll', () => this.handleScroll(), { passive: true });

        // Первичная синхронизация будет выполнена в конце init()

        // Закрытие мобильного меню при клике на ссылку
        if (this.navLinks && this.navLinks.length) {
            this.navLinks.forEach(link => {
                try {
                    link.addEventListener('click', () => {
                        if (this.isMobileMenuOpen) this.closeMobileMenu();
                    });
                } catch (e) { /* ignore invalid nodes */ }
            });
        }

        // Закрытие при изменении размера окна и пересоздание observer (debounced)
        window.addEventListener('resize', () => {
            if (window.innerWidth > 991 && this.isMobileMenuOpen) {
                this.closeMobileMenu();
            }
            // debounce observer recalculation
            if (this._resizeObserverTimeout) clearTimeout(this._resizeObserverTimeout);
            this._resizeObserverTimeout = setTimeout(() => this._onWarningHeightChange(), 160);
        });

        if (this.hasHero) {
            this.observeHero();
            // listen to warning bar height changes so observer rootMargin can be adjusted
            window.addEventListener('warningbar:height', this._onWarningHeightChange.bind(this));
        }

        // Populate contacts from centralized `settings`
        this.populateContacts();

        // Первичная синхронизация состояния перед завершением init
        this.handleScroll();

        // Accessibility: close on Escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isMobileMenuOpen) {
                this.closeMobileMenu();
            }
        });
    }

    /**
     * Наблюдает за видимостью hero и переключает состояние навигации
     * Используется как более надежная замена для чистого скролл-хэндлера
     */
    observeHero() {
        try {
            const hero = document.getElementById('hero');
            if (!hero || !this.nav) return;

            // mobile: no observer
            if (window.innerWidth <= 991) return;

            // always disconnect previous
            if (this._heroObserver) {
                try { this._heroObserver.disconnect(); } catch (e) { }
                this._heroObserver = null;
            }

            const navHeight = this.nav.offsetHeight || 80;

            let warningOffset = 0;
            try {
                const raw = getComputedStyle(document.documentElement)
                    .getPropertyValue('--warning-bar-height') || '0px';
                warningOffset = parseInt(raw, 10) || 0;
            } catch (e) { }

            const io = new IntersectionObserver((entries) => {
                const entry = entries[0];
                const scrolled = !(entry && entry.isIntersecting);

                console.debug('Navigation.observeHero -> scrolled=', scrolled);

                this.nav.classList.toggle('navigation--scrolled', scrolled);
                this._setLogoState(scrolled);
            }, {
                root: null,
                threshold: 0,
                rootMargin: `-${navHeight + warningOffset}px 0px 0px 0px`
            });

            io.observe(hero);
            this._heroObserver = io;

            // initial sync handled from init()
        } catch (e) { }
    }

    /**
     * Обработчик скролла страницы
     */
    handleScroll() {
        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        const threshold = 50;

        // Do not toggle scrolled state on small screens (mobile)
        if (window.innerWidth <= 991) return;

        if (!this.nav) return;

        // If there's no hero, always show white navigation with dark logo
        if (!this.hasHero) {
            this.nav.classList.add('navigation--white');
            this.nav.classList.remove('navigation--scrolled');
            this._setLogoState(true);
            return;
        }

        // With hero: toggle based on scroll threshold
        const scrolled = scrollTop > threshold;
        this.nav.classList.toggle('navigation--scrolled', scrolled);
        this._setLogoState(scrolled);

        this.lastScrollTop = scrollTop;
    }

    _setLogoState(scrolled) {
        if (!this.nav) return;

        const light = this.nav.querySelector('.navigation__logo-img--light');
        const dark = this.nav.querySelector('.navigation__logo-img--dark');
        if (!light || !dark) return;

        // IMPORTANT: remove from layout to stop shifting
        try {
            const beforeInline = light.getAttribute('style');
            const beforeComputed = getComputedStyle(light).display;
            console.debug('Navigation._setLogoState BEFORE -> scrolled=', scrolled, 'nav.classes=', this.nav.className, 'light.inline=', beforeInline, 'light.computed=', beforeComputed, 'el=', light);

            if (scrolled) {
                light.style.display = 'none';
                dark.style.display = '';
            } else {
                light.style.display = '';
                dark.style.display = 'none';
            }

            const afterInline = light.getAttribute('style');
            const afterComputed = getComputedStyle(light).display;
            console.debug('Navigation._setLogoState AFTER -> scrolled=', scrolled, 'light.inline=', afterInline, 'light.computed=', afterComputed, 'dark.computed=', getComputedStyle(dark).display);
        } catch (e) {
            console.debug('Navigation._setLogoState error', e);
        }
    }

    /**
     * Переключение мобильного меню
     */
    toggleMobileMenu() {
        if (this.isMobileMenuOpen) {
            this.closeMobileMenu();
        } else {
            this.openMobileMenu();
        }
    }

    /**
     * Открытие мобильного меню
     */
    openMobileMenu() {

        if (!this.mobileMenu || !this.burgerBtn || !this.nav) return;

        this.isMobileMenuOpen = true;
        this.mobileMenu.classList.add('navigation__mobile--active');
        this.burgerBtn.classList.add('navigation__burger--active');

        // НЕ фиксируем шапку на мобиле — она должна уезжать с контентом
        if (window.innerWidth > 991) {
            this.nav.classList.add('navigation--open');
        }

        // Блокируем скролл body using fixed positioning to avoid iOS issues
        try {
            this._scrollYBeforeLock = window.scrollY || window.pageYOffset || 0;
            document.documentElement.style.setProperty('--scroll-lock-top', `-${this._scrollYBeforeLock}px`);
            document.body.style.position = 'fixed';
            document.body.style.top = `-${this._scrollYBeforeLock}px`;
            document.body.style.width = '100%';
        } catch (e) { /* fallback */ document.body.style.overflow = 'hidden'; }

        // Accessibility
        this.burgerBtn.setAttribute('aria-expanded', 'true');
        this.burgerBtn.setAttribute('aria-label', 'Закрыть меню');
        if (this.mobileMenu) this.mobileMenu.setAttribute('aria-hidden', 'false');

        // Save previously focused element and move focus into menu
        this._previousFocus = document.activeElement;
        const firstFocusable = this.mobileMenu && this.mobileMenu.querySelector('a, button, [tabindex]:not([tabindex="-1"])');
        if (firstFocusable) firstFocusable.focus();

        // Lazy-load mobile logo only when menu opens
        try {
            const mobileLogoImg = this.mobileMenu && this.mobileMenu.querySelector('.navigation__mobile-logo img[data-src]');
            if (mobileLogoImg && mobileLogoImg.dataset && mobileLogoImg.dataset.src) {
                // load only once
                if (!mobileLogoImg.dataset.loaded) {
                    mobileLogoImg.src = mobileLogoImg.dataset.src;
                    mobileLogoImg.dataset.loaded = 'true';
                }
            }
        } catch (e) { /* ignore */ }
    }

    /**
     * Закрытие мобильного меню
     */
    closeMobileMenu() {

        if (!this.mobileMenu || !this.burgerBtn || !this.nav) return;

        this.isMobileMenuOpen = false;
        this.mobileMenu.classList.remove('navigation__mobile--active');
        this.burgerBtn.classList.remove('navigation__burger--active');
        this.nav.classList.remove('navigation--open');

        // Разблокируем скролл body and restore previous scroll position
        try {
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.width = '';
            const prev = this._scrollYBeforeLock || 0;
            window.scrollTo(0, prev);
            this._scrollYBeforeLock = null;
        } catch (e) { document.body.style.overflow = ''; }

        // Accessibility
        this.burgerBtn.setAttribute('aria-expanded', 'false');
        this.burgerBtn.setAttribute('aria-label', 'Открыть меню');
        if (this.mobileMenu) this.mobileMenu.setAttribute('aria-hidden', 'true');

        // Restore focus
        if (this._previousFocus) {
            try { this._previousFocus.focus(); } catch (e) { this.burgerBtn.focus(); }
        } else {
            this.burgerBtn.focus();
        }
    }

    /**
     * Заполняет элементы контактов из `siteData`
     */
    populateContacts() {
        // hours
        const hoursEls = document.querySelectorAll('[data-set="hours"]');
        hoursEls.forEach(el => { el.textContent = settings.company.hours; });

        // phone (text + tel href)
        const phoneEls = document.querySelectorAll('[data-set-link="phone"]');
        phoneEls.forEach(el => {
            if (el.tagName.toLowerCase() === 'a') {
                el.href = `tel:${settings.company.phone_clean}`;
                el.textContent = settings.company.phone;
            } else {
                el.textContent = settings.company.phone;
            }
        });

        // address placeholders (if any)
        const addrEls = document.querySelectorAll('[data-set="address"]');
        addrEls.forEach(el => { el.textContent = settings.company.address; });
    }

    /**
     * Плавная прокрутка к секции
     * @param {string} targetId - ID целевой секции
     */
    scrollToSection(targetId) {
        const target = document.getElementById(targetId);
        if (target) {
            const navHeight = this.nav ? this.nav.offsetHeight : 0;
            // include warning bar height (CSS var) so target isn't hidden under the bar
            let warningOffset = 0;
            try {
                const raw = getComputedStyle(document.documentElement).getPropertyValue('--warning-bar-height') || '0px';
                warningOffset = parseInt(raw, 10) || 0;
            } catch (e) { /* ignore */ }

            const targetPosition = target.offsetTop - navHeight - warningOffset;

            window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
            });
        }
    }
}

// Экспорт для использования в других модулях
export default Navigation;

// expose global for non-module usage (safe try)
try { window.Navigation = Navigation; } catch (e) { /* ignore */ }

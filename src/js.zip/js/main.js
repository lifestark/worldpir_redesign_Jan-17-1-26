import { autofillDescriptionFromH1 } from './description-autofill.js';
// Автоматически подставлять description из первого h1
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autofillDescriptionFromH1);
} else {
    autofillDescriptionFromH1();
}
/**
 * ================================================
 * MAIN.JS
 * Основной JavaScript файл приложения
 * ================================================
 */

// Импорты компонентов
import Navigation from './components/navigation.js';
// import GallerySlider from './components/gallerySlider.js'; // Old slider
import GallerySwiper from './components/gallerySwiper.js'; // New Swiper
import FAQ from './components/faq.js';
import Modal from './components/modal.js';
import PhoneMask from './components/phoneMask.js';
import SmoothScroll from './components/smoothScroll.js';
import ScrollAnimations from './components/scrollAnimations.js';
// Автоматическая подстановка года
import './year.js';
import './settings.js';
import './warning-bar.js';
import './telegram-widget.js';
import './components/filter.js';
import Typograph from './components/typograph.js';

/**
 * ================================================
 * COMPONENT INITIALIZATION
 * Функции для инициализации компонентов
 * ================================================
 */
function initializeNavigation() {
    return new Navigation();
}

function initializeGallerySlider() {
    // new GallerySlider('gallerySlider');
    new GallerySwiper();
}

function initializeFAQ() {
    new FAQ();
}

function initializeModals() {
    new Modal();
}

function initializePhoneMask() {
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        new PhoneMask(phoneInput);
    }
}

function initializeSmoothScroll() {
    new SmoothScroll();
}

function initializeScrollAnimations() {
    new ScrollAnimations();
}

/**
 * ================================================
 * DOMContentLoaded
 * Инициализация всех компонентов после загрузки DOM
 * ================================================
 */
// exported initializers (no side-effects here)
export { initializeNavigation, initializeGallerySlider, initializeFAQ, initializeModals, initializePhoneMask, initializeSmoothScroll, initializeScrollAnimations };

// app-init.js will import these and run the DOMContentLoaded initialization.



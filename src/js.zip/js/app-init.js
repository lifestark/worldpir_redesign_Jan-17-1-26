import { initializeNavigation, initializeGallerySlider, initializeFAQ, initializeModals, initializePhoneMask, initializeSmoothScroll, initializeScrollAnimations } from './main.js';
import Typograph from './components/typograph.js';

// DOMContentLoaded bootstrap
document.addEventListener('DOMContentLoaded', () => {
    const navInstance = initializeNavigation();
    initializeGallerySlider();
    initializeFAQ();
    initializeModals();
    initializePhoneMask();
    initializeSmoothScroll();
    initializeScrollAnimations();

    // Инициализация типографа
    new Typograph();

    // Инициализация warning bar (паттерн-анимация теперь в JS)
    try { if (window && window.initWarningBar) window.initWarningBar(); } catch (e) { /* fail silently */ }

    // Надёжно получаем элемент навигации после загрузки DOM
    const navigation = document.querySelector('.navigation');
    if (!navigation) return;

    // Helper: toggle BEM modifier used in CSS
    function setScrolledState(scrolled) {
        if (scrolled) {
            navigation.classList.add('navigation--scrolled');
        } else {
            navigation.classList.remove('navigation--scrolled');
        }
        // keep logos in sync if navigation instance exists
        try {
            console.debug('main.setScrolledState -> scrolled=', scrolled);
            if (navInstance && typeof navInstance._setLogoState === 'function') {
                navInstance._setLogoState(scrolled);
            }
        } catch (e) { /* ignore */ }
    }

    // Initial state: pages with no hero should appear scrolled
    const isNoHero = document.body.classList.contains('no-hero');
    const hasHero = document.getElementById('hero') !== null;

    // Only apply scrolled state by default on desktop. On mobile we keep it off
    if (window.innerWidth > 991 && (isNoHero || window.scrollY > 0)) {
        setScrolledState(true);
    } else {
        setScrolledState(false);
    }

    // Scroll handler: toggle the modifier used in CSS.
    // Do not interfere on mobile widths or when a hero exists (Navigation handles that).
    window.addEventListener('scroll', () => {
        if (window.innerWidth <= 991) return;
        if (hasHero) return;
        setScrolledState(window.scrollY > 0);
    }, { passive: true });

    // Устанавливаем CSS-переменную --nav-height равной текущей высоте навигации
    function updateNavHeight() {
        const height = navigation.offsetHeight;
        document.documentElement.style.setProperty('--nav-height', `${height}px`);
    }

    // Обновляем при загрузке и при изменении размера окна
    window.addEventListener('load', () => {
        // небольшая задержка, чтобы стили и переходы завершились
        setTimeout(updateNavHeight, 50);
    });

    window.addEventListener('resize', () => {
        clearTimeout(window.__updateNavHeightTimeout);
        window.__updateNavHeightTimeout = setTimeout(updateNavHeight, 120);
    });

    // Также наблюдаем за изменениями внутри навигации (открытие мобильного меню, изменение логотипов и т.п.)
    const observer = new MutationObserver(() => {
        // debounce
        clearTimeout(window.__updateNavHeightMutation);
        window.__updateNavHeightMutation = setTimeout(updateNavHeight, 60);
    });

    observer.observe(navigation, { attributes: true, childList: true, subtree: true });

    // Также обновляем сразу
    updateNavHeight();
});
